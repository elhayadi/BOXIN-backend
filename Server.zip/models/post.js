const mongoose = require("mongoose");
const jwt = require("jsonwebtoken");
const { jwtPrivateKey } = process.env;
const postSchema = new mongoose.Schema(
  {
    author: {
      type: Schema.Types.ObjectId,
      ref: "user",
    },
    service: {
      type: String,
      default: "general",
    },
    media: {
      type: String,
      default: "",
    },
    message: {
      type: String,
      max: 50,
    },
    type: {
      type: String,
      default: "simple",
    },
    answers: {
      type: Array,
      default: [],
    },
    personAnswers: [{ name: String, avatarUrl: String }],
    personLikes: [{ name: String, avatarUrl: String }],
    comments: [
      {
        author: {
          type: Schema.Types.ObjectId,
          ref: "user",
        },
        message: String,
        createdAt: String,
      },
    ],
    status: {
      type: String,
      default: "published",
    },
  },
  { timestamps: true, strict: false }
);

module.exports = mongoose.model("post", postSchema);
