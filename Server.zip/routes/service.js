const auth = require("../middleware/auth");
const admin = require("../middleware/admin");
const _ = require("lodash");
const Service = require("../models/service");
const express = require("express");
const router = express.Router();

router.post("/add", [auth, admin], async (req, res) => {
  try {
    let service = await Service.findOne({ displayName: req.body.displayName });
    console.log(req.body.displayName);
    if (service) return res.status(400).send({ message: "Nom déja utilisé." });
    console.log(req.body.displayName);
    service = new Service(req.body);
    await service.save();

    res.send({ service });
  } catch (error) {
    res.status(400).send({ message: "Internal server error" });
  }
});

router.get("/all", auth, async (req, res) => {
  const services = await Service.find();
  res.send(services);
});
module.exports = router;
